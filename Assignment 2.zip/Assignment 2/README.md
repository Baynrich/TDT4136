# Applying the A:star: algorithm

To view the visualised results, run <code>assignment2.py</code>. 