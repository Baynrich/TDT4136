from ex4 import exercise4
from ex5 import exercise5

astar_1 = exercise4()
astar_1.astar()

astar_2 = exercise4(task=2)
astar_2.astar()

astar_3 = exercise5()
astar_3.astar()

astar_3 = exercise5(task=4)
astar_3.astar()
